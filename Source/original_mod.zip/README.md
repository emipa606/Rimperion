<p align="center">
    <img src="https://github.com/jhjjgu0115/Rimperion/blob/master/About/Preview.png" />
</p>
<p align="center">
  <a href="https://github.com/jhjjgu0115/Rimperion/releases">
    <img src="https://img.shields.io/badge/release-v0.2-0066cc.svg?style=flat" alt="v0.2" />
  </a>
  <a href="https://github.com/jhjjgu0115/Rimperion/wiki">
    <img src="https://img.shields.io/badge/documentation-Wiki-cc0303.svg?style=flat" alt="Documentation" />
  </a>  
  <a href="https://github.com/jhjjgu0115/RimBuff">
    <img src="https://img.shields.io/badge/Need Mod-RimBuff-33CC99.svg?style=flat" alt="NeedMod" />
  </a>
</p>

<p align="center">
 Adds Borderlands Hyperion style Weapon
</p>

---------------------------------------

#### Feature
"Bringing perfection to the field."  
All Hyperion weapons get more accurate each time it fires.  
Negative Recoil,a special Recoil control technology only for Hyperion makers, gives you the best precision.  

#### Negative Recoil
- Negative Recoil increases the accuracy rate every time a gun is fired.
- If you stop shooting, it will be restored rapidly.  

